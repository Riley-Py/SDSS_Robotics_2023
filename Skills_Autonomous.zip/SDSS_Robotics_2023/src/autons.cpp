#include "main.h"
#include "definitions.hpp"


/////
// For instalattion, upgrading, documentations and tutorials, check out website!
// https://ez-robotics.github.io/EZ-Template/
/////


const int DRIVE_SPEED = 110; // This is 110/127 (around 87% of max speed).  We don't suggest making this 127.
                             // If this is 127 and the robot tries to heading correct, it's only correcting by
                             // making one side slower.  When this is 87%, it's correcting by making one side
                             // faster and one side slower, giving better heading correction.
const int TURN_SPEED  = 90;
const int SWING_SPEED = 90;



///
// Constants
///

// It's best practice to tune constants when the robot is empty and with heavier game objects, or with lifts up vs down.
// If the objects are light or the cog doesn't change much, then there isn't a concern here.

void default_constants() {
  chassis.set_slew_min_power(80, 80);
  chassis.set_slew_distance(7, 7);
  chassis.set_pid_constants(&chassis.headingPID, 11, 0, 20, 0);
  chassis.set_pid_constants(&chassis.forward_drivePID, 0.45, 0, 5, 0);
  chassis.set_pid_constants(&chassis.backward_drivePID, 0.45, 0, 5, 0);
  chassis.set_pid_constants(&chassis.turnPID, 5, 0.003, 35, 15);
  chassis.set_pid_constants(&chassis.swingPID, 7, 0, 45, 0);
}

void one_mogo_constants() {
  chassis.set_slew_min_power(80, 80);
  chassis.set_slew_distance(7, 7);
  chassis.set_pid_constants(&chassis.headingPID, 11, 0, 20, 0);
  chassis.set_pid_constants(&chassis.forward_drivePID, 0.45, 0, 5, 0);
  chassis.set_pid_constants(&chassis.backward_drivePID, 0.45, 0, 5, 0);
  chassis.set_pid_constants(&chassis.turnPID, 5, 0.003, 35, 15);
  chassis.set_pid_constants(&chassis.swingPID, 7, 0, 45, 0);
}

void two_mogo_constants() {
  chassis.set_slew_min_power(80, 80);
  chassis.set_slew_distance(7, 7);
  chassis.set_pid_constants(&chassis.headingPID, 11, 0, 20, 0);
  chassis.set_pid_constants(&chassis.forward_drivePID, 0.45, 0, 5, 0);
  chassis.set_pid_constants(&chassis.backward_drivePID, 0.45, 0, 5, 0);
  chassis.set_pid_constants(&chassis.turnPID, 5, 0.003, 35, 15);
  chassis.set_pid_constants(&chassis.swingPID, 7, 0, 45, 0);
}


void modified_exit_condition() {
  chassis.set_exit_condition(chassis.turn_exit, 100, 3, 500, 7, 500, 500);
  chassis.set_exit_condition(chassis.swing_exit, 100, 3, 500, 7, 500, 500);
  chassis.set_exit_condition(chassis.drive_exit, 80, 50, 300, 150, 500, 500);
}

void skillsRoute() {

   //Variable to hold the amount of milliseconds that have passed
   unsigned long shooter;
   
   //Drives on the diagonal
   chassis.set_drive_pid(28, DRIVE_SPEED, true);
   chassis.wait_drive();
   
   //Turns 45 degrees clockwise
   chassis.set_turn_pid(45, TURN_SPEED);
   chassis.wait_drive();
   
  //Moves the intake while moving the triballs in
  intake.move_voltage(12000);
  chassis.set_drive_pid(11, DRIVE_SPEED);
  chassis.wait_drive();
  
  //Stops intake
  intake.move_voltage(0);

  //Go back a bit
  chassis.set_drive_pid(-12, DRIVE_SPEED);
  chassis.wait_drive();

  //Turn 180 degrees (180 + 45)
  chassis.set_turn_pid(225, TURN_SPEED);
  chassis.wait_drive();

 
  // Drive right into the net again to guarntee that the triballs are in
  chassis.set_drive_pid(-18.5, DRIVE_SPEED, true);
  chassis.wait_drive();

  //Comes back a bit
  chassis.set_drive_pid(19.5, DRIVE_SPEED, true);
  chassis.wait_drive();
  
  //Turns to the angle that is perfectly position to shoot in the net (DO NOT CHANGE!!!!)
  chassis.set_turn_pid(295, TURN_SPEED);
  chassis.wait_drive();
  
  //Lowers intake so that we are "in" load zone (true = pneumatics engaged; false = pneumatics not engaged)
  intakeExtender.set_value(true);

  
  //Setsthe amount of time already passed
  shooter = millis();
  
  //Shoots for 28 seconds (that's as fast as we could go without having to be super-perfect; can shorten this if it proves an issue)
  while (millis() - shooter != 28000) {
    cata.move_voltage(12000);
  }
  cata.brake();
  
  //Raises intake
  intakeExtender.set_value(false);
  
  //Turns a bit
  chassis.set_turn_pid(290, TURN_SPEED);
  chassis.wait_drive();

  //Drives on a diagonal (may have to increase to get out of the way of the corner triball on the right)
  chassis.set_drive_pid(-38, DRIVE_SPEED, true);
  chassis.wait_drive();
  
  //Turns again to be relatively perpendicular to the center bar
  chassis.set_turn_pid(310, TURN_SPEED);
  chassis.wait_drive();
  
  //Slams into the bar just in case there are triballs that are missed
  chassis.set_drive_pid(-30, DRIVE_SPEED);
  chassis.wait_drive();
  
  //Drives back, gettting ready for the push
  chassis.set_drive_pid(20, DRIVE_SPEED);
  chassis.wait_drive();
  

  //The robot goes over the barrier (DO NOT CHANGE; THE POWER LEVEL HAS TO BE THIS TO GET OVER)
  chassis.set_drive_pid(-88, 127);
  chassis.wait_drive();
  
  //Turns the robot in the right orientation for the wings to pick up triballs
  chassis.set_turn_pid(125, TURN_SPEED);
  wings.set_value(true);
  chassis.wait_drive();
  
  //Drives into the net
  chassis.set_drive_pid(25, DRIVE_SPEED);
  chassis.wait_drive();
  
  //Backs up
  chassis.set_drive_pid(-25, DRIVE_SPEED);
  chassis.wait_drive();
  
  //Disengages wings for this moment and turns to be about parallel with the net
  wings.set_value(false);
  chassis.set_turn_pid(70, TURN_SPEED);
  chassis.wait_drive();
  
  //Drives to the left (right if looking at the scoring net head on)
  chassis.set_drive_pid(25, DRIVE_SPEED);
  chassis.wait_drive();
  
  //Turns into the net at an angle
  chassis.set_turn_pid(110, TURN_SPEED);
  chassis.wait_drive();

  //Engages the wings again and pushes the triballs in a new position
  wings.set_value(true);
  chassis.set_drive_pid(45, DRIVE_SPEED);
  chassis.wait_drive();
  
  //Backs up the drivetrain once more
  chassis.set_drive_pid(-25, DRIVE_SPEED);
  chassis.wait_drive();
  
  /*TO-DO: ADJUST THIS IN ORDER TO HAVE THE CORRECT VALUES OR ELSE IT DRIVES RIGHT INTO THE NET
  chassis.set_turn_pid(190, TURN_SPEED);
  chassis.wait_drive();

  chassis.set_drive_pid(25, DRIVE_SPEED);
  chassis.wait_drive();

  chassis.set_turn_pid(180, TURN_SPEED);
  chassis.wait_drive();

  chassis.set_drive_pid(45, DRIVE_SPEED);
  chassis.wait_drive();

  chassis.set_drive_pid(-25, DRIVE_SPEED);
  chassis.wait_drive();
  */

}
