/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\sebas                                            */
/*    Created:      Wed Mar 01 2023                                           */
/*    Description:  Seb can't drive using Hark's controls                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// rightMotors          motor_group   19, 20          
// leftMotors           motor_group   16, 17          
// leftTop              motor         15              
// rightTop             motor         18              
// cataMotor            motor         12              
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

#include <cmath>

using namespace vex;

//Joystick curve setup
int turningCurve = 3;
bool turningRed = false;

int forwardCurve = 3;
bool forwardRed = false;

// graph of red and blue lines from 5225A here
int curveJoystick(bool red, int input, double t) {
  int val = 0;
  if (red) {
    val = (std::exp(-t / 10) +
           std::exp((std::abs(input) - 100) / 10) * (1 - std::exp(-t / 10))) *
          input;
  } else {
    // blue
    val = std::exp(((std::abs(input) - 100) * t) / 1000) * input;
  }
  return val;
}

void usercontrol(void) {

  leftMotors.setStopping(coast);
  rightMotors.setStopping(coast);
  leftTop.setStopping(coast);
  rightTop.setStopping(coast);
  cataMotor.setStopping(hold);
  cataMotor.setMaxTorque(100, percent);

  int deadzone = 3;

  while (1) {
    double turnVal = curveJoystick(
        true, Controller1.Axis1.position(percent),
        turningCurve); // Get curvature according to settings [-100,100]
    double forwardVal = curveJoystick(
        true, Controller1.Axis3.position(percent),
        forwardCurve); // Get curvature according to settings [-100,100]

    double turnVolts = (turnVal * 0.12) * 0.80;       // Converts to voltage
    double forwardVolts = forwardVal * 0.12; // Converts to voltage

    if (Controller1.Axis1.position(percent) >> deadzone) {
      leftMotors.spin(forward, forwardVolts + turnVolts,
                      voltageUnits::volt); // Apply Via Voltage
      leftTop.spin(forward, forwardVolts + turnVolts, voltageUnits::volt);
      rightMotors.spin(forward, forwardVolts - turnVolts, voltageUnits::volt);
      rightTop.spin(forward, forwardVolts - turnVolts, voltageUnits::volt);

    } else if (Controller1.Axis3.position(percent) >> deadzone) {
      leftMotors.spin(forward, forwardVolts + turnVolts,
                      voltageUnits::volt); // Apply Via Voltage
      leftTop.spin(forward, forwardVolts + turnVolts, voltageUnits::volt);
      rightMotors.spin(forward, forwardVolts - turnVolts, voltageUnits::volt);
      rightTop.spin(forward, forwardVolts - turnVolts, voltageUnits::volt);

    } else {
      leftMotors.stop();
      rightMotors.stop();
      leftTop.stop();
      rightTop.stop();
    }

    if (Controller1.ButtonR1.pressing()) {
      cataMotor.spin(forward);
    } else if (Controller1.ButtonR2.pressing()) {
      cataMotor.spin(reverse);
    } else {
      cataMotor.stop();
    }

    vex::task::sleep(20);
  }
}

int main() {

  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  usercontrol();
}