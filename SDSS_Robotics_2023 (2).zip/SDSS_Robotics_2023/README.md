# SDSS_Robotics_2023
Code for the robot and diagrams for the autonomous routine
