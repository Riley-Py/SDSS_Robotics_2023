#pragma once

#include "EZ-Template/drive/drive.hpp"

extern Drive chassis;

void turnLeft();
void turnRight();
void skillsRoute();

void default_constants();
void one_mogo_constants();
void two_mogo_constants();